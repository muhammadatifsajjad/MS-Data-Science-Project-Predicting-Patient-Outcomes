import os
import datetime
os.chdir(r'C:\\Users\\demo\\Desktop\\SequencePrediction\\CPT')


import pickle
from CPT import *
model = CPT()
train,test = model.load_files("C:/Users/demo/Desktop/SequencePrediction/SequencePrediction/train.csv","C:/Users/demo/Desktop/SequencePrediction/SequencePrediction/test.csv",merge = True)
model.train(train)

print(datetime.datetime.now())
predictions = model.predict(train,test[0:30000],5,1)
print(datetime.datetime.now())

with open('predictions.pickle', 'wb') as f:
    pickle.dump(predictions, f)

a = pd.DataFrame(predictions)
    
a.to_csv('cpt_predictions.csv', index=False)

answers = pd.read_csv('answers.csv')
cpt_predictions_df = pd.read_csv('cpt_predictions.csv')

answers['ANSWER'].dtype
cpt_predictions_df['PRED'].dtype

cpt_predictions_df = cpt_predictions_df.astype(int)

accuracy_score(cpt_predictions_df, answers) * 100
precision_score(cpt_predictions_df, answers, average="weighted") * 100
recall_score(cpt_predictions_df, answers, average="macro") * 100