import copy
import sys


def appendToAllElems(listOfList, elemToAppend):
    for list in listOfList:
        list.append(elemToAppend)


def copyAndAppendInOrder(listOfList, elemsToAppend):
    oneCopy = copy.deepcopy(listOfList)
    appendToAllElems(listOfList, elemsToAppend[0])
    for i in range(0, len(elemsToAppend) - 1):
        curCopy = copy.deepcopy(oneCopy)
        appendToAllElems(curCopy, elemsToAppend[i + 1])
        listOfList.extend(curCopy)


def getAllPossibleSequences(inputSeq):
    collectedSeqs = [[]]
    i = 0
    n = len(inputSeq)
    for pos in inputSeq:
        j = (i + 1) / n
        sys.stdout.write('\r')
        sys.stdout.write(
            "Getting all possible sequences: [%-20s] %d%% -- current sequence length: %d -- computed seqs: %d" % (
            '=' * int(20 * j), 100 * j, n, len(collectedSeqs)))
        i += 1
        copyAndAppendInOrder(collectedSeqs, pos)
    return collectedSeqs;


def getNumberOfCombinations(inputSeq):
    comb = 1
    for pos in inputSeq:
        comb = comb * len(pos)
    return comb
