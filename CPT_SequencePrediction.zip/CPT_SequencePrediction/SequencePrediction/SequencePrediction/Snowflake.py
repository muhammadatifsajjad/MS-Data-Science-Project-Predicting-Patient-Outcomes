import os
from sqlalchemy import create_engine
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.feature_selection import VarianceThreshold
import snowflake.connector as sf

os.chdir(r'C:\\FINAL')

sf_conn = sf.connect(user='MuhammadAtif@UniMel', password='Inbox@123',
                     account='ti70021.ap-southeast-2')
# Read patient disease history from MySQL database       
nd_patient_history_disease = pd.read_sql("SELECT MASTERPATIENTID , DISPENSECALENDARDATE, listagg(DISTINCT PBSDISEASEGROUP, '| ') \
FROM \
( \
  SELECT MASTERPATIENTID, DISPENSECALENDARDATE, PBSDISEASEGROUP, ROW_NUMBER() OVER (PARTITION BY MASTERPATIENTID, DISPENSECALENDARDATE ORDER BY PBSDISEASEGROUP ASC) RN \
  FROM ppo.nd_patient_history_distinct_diseases_final_20191020 \
  ORDER BY MASTERPATIENTID, DISPENSECALENDARDATE \
) A \
WHERE RN = 1 \
GROUP BY DISPENSECALENDARDATE, MASTERPATIENTID \
ORDER BY MASTERPATIENTID, DISPENSECALENDARDATE;", con=sf_conn)   

nd_patient_history_disease.to_csv("data_new.csv", index=False)