import os

os.chdir(r'C:\\Users\\demo\\Desktop\\SequencePrediction\\SequencePrediction')

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1


fileLen = file_len('allSeqs.csv')

print(fileLen)
trainSplit = .70 * fileLen
print(trainSplit)

f = open('allSeqs.csv', "r")
counter = 0

filepath = 'allSeqs.csv'

with open(filepath) as allFile, open('train.csv', 'w') as trainFile, open('test.csv', 'w') as testFile, open('answers.csv', 'w') as answerFile:
    line = allFile.readline()
    cnt = 1
    while line and cnt < trainSplit:
        print(line.strip(), file=trainFile)
        line = allFile.readline()
        cnt += 1
    while line:
        lineval = line.strip()
        linevals = lineval.split(',')
        print(linevals[-1], file=answerFile)
        stringToWrite = ""
        linevals = linevals[:-1]
        for x in linevals:
            stringToWrite=stringToWrite+","+x
        print(stringToWrite[1:], file=testFile)
        line = allFile.readline()
        cnt += 1
