# Dump data using following sql, save output to data.csv:
# SELECT MASTERPATIENTID , DISPENSECALENDARDATE,GROUP_CONCAT(DISTINCT GENERICINGREDIENTNAME SEPARATOR '| ')
# FROM predictpatientoutcomes.nd_patient_history_distinct_medicines_final
# GROUP BY DISPENSECALENDARDATE, MASTERPATIENTID
# ORDER BY MASTERPATIENTID, DISPENSECALENDARDATE

import os

os.chdir(r'C:\\Users\\demo\\Desktop\\SequencePrediction\\SequencePrediction')

import csv
from getSeq import getAllPossibleSequences
from getSeq import getNumberOfCombinations

import os
import time


t0 = time.time()

patients = {}
medicines = {}
maxLength = 0

with open('data_new.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
        if not patients.get(row[0]):
            patients[row[0]] = {}
        meds = row[2].split('| ')
        patients[row[0]][row[1]] = meds
        for med in meds:
            if med not in medicines:
                medicines[med] = len(medicines)

try:
    os.remove("allSeqs.csv")
except:
    dummy = 0

maxLength = 0
maxpat = ""
for pat in patients:
    if maxLength < len(patients[pat]):
        maxLength = len(patients[pat])
        maxpat = pat

print("----------------Data Stats----------------")

print("Longest patient history found", maxLength, "for", maxpat)

with open('allSeqs.csv', 'a', newline='') as myfile:
    wr = csv.writer(myfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    wr.writerow(range(1, maxLength + 1))

maxComb = 0
allComb = 0
mostComPat = ""
for pat in patients:
    i = 1
    for date in patients[pat]:
        i = i * len(patients[pat][date])
    if maxComb < i:
        maxComb = i
        mostComPat = pat
    allComb = allComb + i

print("Foretasted longest combination sequence length:", maxComb, "for", mostComPat)
print("Foretasted number of sequences:", allComb)

print("-------------Processing Sequences---------")

allSeqs = []
i = 0
patlen = len(patients)
for patient in patients:
    print('\n-> Progress: ', i * 100 / patlen, '%')
    i += 1
    patientSeqs = []
    for date in patients[patient]:
        patientSeqs.append([medicines[x] for x in patients[patient][date]])
    #if getNumberOfCombinations(patientSeqs) <= 100000000000000000000:  # Crude dev flag, remove this if for actual prediction
    with open('allSeqs.csv', 'a', newline='') as myfile:
        wr = csv.writer(myfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        wr.writerows(getAllPossibleSequences(patientSeqs))

t1 = time.time()
totalTime = t1 - t0

print("\nTime taken:", totalTime, "secs")
